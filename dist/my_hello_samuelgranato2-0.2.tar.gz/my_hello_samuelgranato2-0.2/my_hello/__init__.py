# __init__.py

from .my_hello import world